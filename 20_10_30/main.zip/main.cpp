#include <iostream>
#include <vector>

template<class T>
class stack{
    std::vector<T> storage;
public:
    void push(T new_elem)
    {
        storage.push_back(new_elem);
    }

    T pop()
    {
        T result = storage.back();
        storage.pop_back();
        return result;
    }
};

int main() {
    stack<char> first;
    first.push(49); //ASCII code for '1'
    std::cout << first.pop() << std::endl;
    return 0;
}
